var searchData=
[
  ['begin_142',['begin',['../class_bump___switch.html#ac5049af12039af917a1190594d07315d',1,'Bump_Switch::begin()'],['../class_g_p2_y0_a21___sensor.html#ace68b9646a020428fb26d525a945c1ab',1,'GP2Y0A21_Sensor::begin()'],['../class_romi___motor___power.html#aa04e72e97f1dd10631e4844e26072a3f',1,'Romi_Motor_Power::begin()']]]
];
