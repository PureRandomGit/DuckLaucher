var searchData=
[
  ['calibrationoff_199',['calibrationOff',['../class_q_t_r_sensors.html#a868276364c39750f9914abd50ec68c9d',1,'QTRSensors']]],
  ['calibrationon_200',['calibrationOn',['../class_q_t_r_sensors.html#adba8c75f5bc2cf57732ee2b96507f339',1,'QTRSensors']]]
];
