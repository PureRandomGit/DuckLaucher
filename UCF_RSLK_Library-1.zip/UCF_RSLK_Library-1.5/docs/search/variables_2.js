var searchData=
[
  ['maximum_202',['maximum',['../struct_q_t_r_sensors_1_1_calibration_data.html#a6dde6acb179f033a1f3fc08cc048de43',1,'QTRSensors::CalibrationData']]],
  ['minimum_203',['minimum',['../struct_q_t_r_sensors_1_1_calibration_data.html#a2c28f12a4f9aecb33eefa74638092ed8',1,'QTRSensors::CalibrationData']]]
];
