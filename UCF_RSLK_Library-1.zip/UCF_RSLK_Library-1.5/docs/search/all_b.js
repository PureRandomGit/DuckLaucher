var searchData=
[
  ['read_87',['read',['../class_bump___switch.html#ae3c38668a94ddaa370393ffb600abadc',1,'Bump_Switch::read()'],['../class_g_p2_y0_a21___sensor.html#ae9f0e8d0354e38d1024f2e3b01cca42b',1,'GP2Y0A21_Sensor::read()'],['../class_q_t_r_sensors.html#a92f25ec98543d6e87bf65a9db67c69ef',1,'QTRSensors::read()']]],
  ['readcalibrated_88',['readCalibrated',['../class_q_t_r_sensors.html#aa2f5d7779744e5d93f6935d2cdf589eb',1,'QTRSensors']]],
  ['readcallinesensor_89',['readCalLineSensor',['../_simple_r_s_l_k_8h.html#a2801c4f78d97b3cba0c2c012d050d118',1,'SimpleRSLK.cpp']]],
  ['readlineblack_90',['readLineBlack',['../class_q_t_r_sensors.html#a8f2a5239ae547928284c5f81cd7ec89c',1,'QTRSensors']]],
  ['readlinesensor_91',['readLineSensor',['../_simple_r_s_l_k_8h.html#ac4f2d1d309c725ee6929125e316cc497',1,'SimpleRSLK.cpp']]],
  ['readlinewhite_92',['readLineWhite',['../class_q_t_r_sensors.html#a231f1ef20c2a7ba325bdb794fc2dedf9',1,'QTRSensors']]],
  ['readsharpdist_93',['readSharpDist',['../_simple_r_s_l_k_8h.html#a5e95b57608faa5b47f890cd5bd5a953a',1,'SimpleRSLK.cpp']]],
  ['releaseemitterpins_94',['releaseEmitterPins',['../class_q_t_r_sensors.html#af4fea64349f7d85830b41ded4aa63ce8',1,'QTRSensors']]],
  ['resetcalibration_95',['resetCalibration',['../class_q_t_r_sensors.html#aa840b6ef17562d41edf21ddd08e0672e',1,'QTRSensors']]],
  ['resetleftencodercnt_96',['resetLeftEncoderCnt',['../_encoder_8h.html#ab3db3c23b8153c41d80fd7f56a249c1c',1,'Encoder.cpp']]],
  ['resetrightencodercnt_97',['resetRightEncoderCnt',['../_encoder_8h.html#a999ff39a1fcc3afe4e52e055534ebfd7',1,'Encoder.cpp']]],
  ['resumemotor_98',['resumeMotor',['../class_romi___motor___power.html#a845369e911a8ee1f7f5d23f80a909545',1,'Romi_Motor_Power::resumeMotor()'],['../_simple_r_s_l_k_8h.html#af60a0a67c52dde2c566faa7178431441',1,'resumeMotor():&#160;SimpleRSLK.cpp']]],
  ['right_5fmotor_99',['RIGHT_MOTOR',['../_simple_r_s_l_k_8h.html#ac9564ecabfd6f53bee9dc0742d63e19d',1,'SimpleRSLK.h']]],
  ['romi_5fmotor_5fpower_100',['Romi_Motor_Power',['../class_romi___motor___power.html',1,'']]],
  ['rslk_5fpins_2eh_101',['RSLK_Pins.h',['../_r_s_l_k___pins_8h.html',1,'']]]
];
